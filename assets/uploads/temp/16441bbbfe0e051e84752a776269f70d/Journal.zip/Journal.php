<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Journal extends CI_Controller {
    public $userData;
    public function __construct(){
        parent::__construct();
        $this->load->helper(['form','global']);
        $this->load->model(['BudgetModel','MasterModel','JournalModel','EapuModel']);
		
        if ($this->session->has_userdata('user_data'))
		$this->userData = $this->session->userdata('user_data');
		
		else
		return redirect('login', 'Location');
		
		//set_time_limit(600);
		//ini_set('max_execution_time', '600');
    }
    public function index(){
        redirect(base_url('journal/cabang'));
    }
	
	private function get_filter_query($filter='')
	{
		if (empty($filter))
		$filter = $this->input->get();
		
		$filter_query = trim(http_build_query($filter));
		
		if (!empty($filter_query))
		$filter_query = '?'.$filter_query;
		
		return $filter_query;
	}
	
    public function cabang($type=''){
        $page = 'pages/journal/jurnal_cabang';
        $filter = $this->input->get();
        $filter['status'] = 0;
        if($type=='uploaded'){
            $filter['status'] = 1;
            $page='pages/journal/jurnal_cabang_uploaded';
        }elseif($type!=''){
            redirect(base_url('journal/cabang'));
        }
        $filter['type']=$this->JournalModel->filter_type['cabang'];
		
        $jurnalUploadSelection = $this->db->select('year,month')
        ->where('status',$filter['status'])
        ->where_in('type',$filter['type'])
        ->group_by('year,month')->get('tbl_journal')->result();
		
        $this->load->view('includes/header',[
            'user'=>$this->userData,
            'MasterModel'=>$this->MasterModel,
            'suspense_code'=>$this->JournalModel->suspense_code,
			//'jurnal_data'=>$this->JournalModel->get($filter),
			'jurnal_data'=>array(),
            'jurnalUploadSelection'=>$jurnalUploadSelection,
			'getBranch' => $this->MasterModel->getBranchByAdmin(),
			'filter_query' => $this->get_filter_query($filter),
			'filter' => $filter
        ]);
        $this->load->view($page);
        $this->load->view('includes/footer');
    }
    public function ho($type=''){
        $page = 'pages/journal/jurnal_ho';
        $filter = $this->input->get();
        $filter['status'] = 0;
        if($type=='uploaded'){
            $filter['status'] = 1;
            $page='pages/journal/jurnal_ho_uploaded';
        }elseif($type!=''){
            redirect(base_url('journal/ho'));
        }
        $filter['type']=$this->JournalModel->filter_type['ho'];
        $jurnalUploadSelection = $this->db->select('year,month')
        ->where('status',$filter['status'])
        ->where_in('type',$filter['type'])
        ->group_by('year,month')->get('tbl_journal')->result();
        $this->load->view('includes/header',[
            'user'=>$this->userData,
            'MasterModel'=>$this->MasterModel,
            'suspense_code'=>$this->JournalModel->suspense_code,
            //'jurnal_data'=>$this->JournalModel->get($filter),
			'jurnal_data'=>array(),
            'jurnalUploadSelection'=>$jurnalUploadSelection,
			'getBranch' => $this->MasterModel->getBranchByAdmin(),
			'filter_query' => $this->get_filter_query($filter),
			'filter' => $filter
        ]);
        $this->load->view($page);
        $this->load->view('includes/footer');
    }
    public function notadebet($type=''){
        $page = 'pages/journal/jurnal_notadebet';
        $filter = $this->input->get();
        $filter['status'] = 0;
        if($type=='uploaded'){
            $filter['status'] = 1;
            $page='pages/journal/jurnal_notadebet_uploaded';
        }elseif($type!=''){
            redirect(base_url('journal/notadebet'));
        }
        $filter['type']=$this->JournalModel->filter_type['notadebet'];
        $jurnalUploadSelection = $this->db->select('year,month')
        ->where('status',$filter['status'])
        ->where_in('type',$filter['type'])
        ->group_by('year,month')->get('tbl_journal')->result();
        $this->load->view('includes/header',[
            'user'=>$this->userData,
            'MasterModel'=>$this->MasterModel,
            'suspense_code'=>$this->JournalModel->suspense_code,
            //'jurnal_data'=>$this->JournalModel->get($filter),
			'jurnal_data'=>array(),
            'jurnalUploadSelection'=>$jurnalUploadSelection,
			'getBranch' => $this->MasterModel->getBranchByAdmin(),
			'filter_query' => $this->get_filter_query($filter),
			'filter' => $filter
        ]);
        $this->load->view($page);
        $this->load->view('includes/footer');
    }

    public function mark(){
        $id = $this->input->post('check');
        $update = $this->JournalModel->mark($id);
        if($update){
            echo json_encode(['success'=>true,'message'=>'Success']);
        }else{
            echo json_encode(['success'=>false,'message'=>'Failed']);
        }
    }
    public function unmark(){
        $id = $this->input->post('check');
        $update = $this->JournalModel->unmark($id);
        if($update){
            echo json_encode(['success'=>true,'message'=>'Success']);
        }else{
            echo json_encode(['success'=>false,'message'=>'Failed']);
        }
    }

    public function upload($type, $is_unupload=0)
	{
        $data = [
            'header' => [
                ["Record ID","Voucher","Posting Date","Sys Date","Value Date","Description","Second Description","Business Relation (IC Posting)","External Invoice Reference","Parent Text","GL Period","Year","GL Cal Yr/GL Pd","External Origin","Origin Ref","Origin Doc","Origin Pay Type","Origin Trans Type","Origin Daybook Code","Origin Daybook Number","Batch Number","Address Code","Original Posting Reference","Is Replacement","Is Reversal","Correction","Zero Value Allowed","Skip Auto Assign BC","Sequence Number","Additional GL Numbering Date","Additional GL Numbering Reversal Date","Verify Status","Verify Comments","Last Verified Date","Last Verified Time","Approve Status","Approve Comments","Last Approved Date","Last Approved Time","Mirroring Reference","Automatic Reversal","Automatic Reversal Type","Reversal Posting Date","Bank Import Reference","Correction","Creation Date","Creation Time","Transient Reference","Base Currency","Statutory Currency","Template Code","Save As Template","Shared Company ID","Year for Calculating GL Numbering","Additional GL Numbering Enabled","Original Voucher","Original Posting ID","Daybook Code","Type","Daybook Type","Login","Period Type","Reporting Daybook Code","Daybook Access Allowed","Record ID","Seq","Description","BC Debit"," TC Debit "," SC Debit "," pc Debit "," BC Credit "," TC Credit ","SC Credit","pc Credit","Proj","Quantity","Prj","Cost Center","SAF","Exchange Rate","Scale Factor","SC Exchange Rate","SC Scale Factor","GL Cal Yr/GL Pd","Posting Date","Ext Reference (Cross-Cy)","Origin Line No","Mirroring Reference","Mirroring Type","Additional Sequence Number","Gross Income Accounting Reference","Additional Sequence Date","Legal Document","Description","GL Account","Base Curr","Tax","GL Description","Auto","GL Type","UM","Allocation","Allocation Key","Open Item Posting","Intercompany Code","Trans Curr","Sub-Account Code","Cost Center Code","Project Code","Debit/Credit","Currency (Cross-Cy)","GL (Cross-Cy)","Interco-Code (Cross-Cy)","Cross-Company Code","Sub Account Description","Cr Cy Posting Linked To Daemon","Cost Centre Description","Skip COA Val for PC","Consumption Tax Code","GLIsConsumptionVat","Consumption Tax Domain","Consumption Tax In/Out","Record ID","Parent Type","Seq","SAF Code","SAF Concept Code","Structure","Record ID","BC Base Debit","TC Base Debit","SC Base Debit","BC Base Credit","TC Base Credit","SC Base Credit","Rate","Scale Factor","In/Out","Tax Date","Tax Trans Type","Trans Type","BC Tax Debit","SC Tax Debit","TC Tax Debit","BC Tax Credit","SC Tax Credit","TC Tax Credit","Federal Tax","State Tax","Misc Tax 1","Misc Tax 2","Misc Tax 3","Own Federal Tax","Own State Tax","Own Misc Tax 1","Own Misc Tax 1","Own Misc Tax 3","Own Declaration Tax","Reverse Charge","Absorbed Retained","Susp/Del","Tax Type","Tax Class","Tax Usage","Tax Env","From Tax Zone","To Tax Zone","Curr","TC Debit","TC Credit","TC Tax Debit","TC Tax Credit","Tax Code","Description","Domain","In/Out","Tax Group Code","Record ID","BC Base Debit","BC Base Credit","TC Base Debit","TC Base Credit","SC Base Debit","SC Base Credit","Tax Point Date","BC Tax Balance","BC Tax Original","Open","Rate","Scale Factor","Federal Tax ID","State","Misc 1","Misc 2","Misc 3","Own Federal Tax ID","Own State Tax ID","Own Misc 1 ID","Own Misc 2 ID","Own Misc 3 ID","Own Tax Decalaration","Tax Code","Description","TC Debit","TC Credit","TC Tax Debit","TC Tax Credit","Curr","Domain","In/Out","Record ID","BC Base Debit","TC Base Debit","SC Base Debit","BC Base Credit","TC Base Credit","SC Base Credit","Rate","Scale Factor","In/Out","Tax Date","Tax Trans Type","Trans Type","BC Tax Debit","SC Tax Debit","TC Tax Debit","BC Tax Credit","SC Tax Credit","TC Tax Credit","Federal Tax","State Tax","Misc Tax 1","Misc Tax 2","Misc Tax 3","Own Federal Tax","Own State Tax","Own Misc Tax 1","Own Misc Tax 1","Own Misc Tax 3","Own Declaration Tax","Tax Type","Tax Class","Tax Usage","Tax Env","From Tax Zone","To Tax Zone","CurrencyCode","Tax Code","TC Debit","TC Credit","Domain Code","In/Out"],
                ["tPosting.Posting_ID","tPosting.PostingVoucher","tPosting.PostingDate","tPosting.PostingSystemDate","tPosting.PostingValueDate","tPosting.PostingText","tPosting.PostingSecondText","tPosting.PostingBusinessRelationTxt","tPosting.PostingInvoiceReferenceTxt","tPosting.PostingParentText","tPosting.PostingPeriod","tPosting.PostingYear","tPosting.PostingYearPeriod","tPosting.PostingOriginIsExternal","tPosting.PostingOriginReference","tPosting.PostingOriginDocument","tPosting.PostingOriginDocumentType","tPosting.PostingOriginTransType","tPosting.PostingOriginDaybookCode","tPosting.PostingOriginDaybookNumber","tPosting.PostingBatchNumber","tPosting.PostingOriginAddressCode","tPosting.PostingOriginatorReference","tPosting.PostingIsReplacement","tPosting.PostingIsReversing","tPosting.PostingIsReversingBySign","tPosting.PostingIsZeroValueAllowed","tPosting.PostingIsSkipAutoAssignLC","tPosting.PostingAddGLNbr","tPosting.PostingAddGLNbrDate","tPosting.PostingAddGLNbrRevDate","tPosting.PostingVerifyStatus","tPosting.PostingVerifyComments","tPosting.PostingVerifiedDate","tPosting.PostingVerifiedTime","tPosting.PostingApproveStatus","tPosting.PostingApproveComments","tPosting.PostingApprovedDate","tPosting.PostingApprovedTime","tPosting.PostingMirrorRef","tPosting.PostingIsAutoReversal","tPosting.PostingAutoReversalType","tPosting.PostingAutoReversalDate","tPosting.PostingBankImpRef","tPosting.PostingIsCorrection","tPosting.PostingCreationDate","tPosting.PostingCreationTimeString","tPosting.PostingTransientRef","tPosting.tcLocalCurrency","tPosting.tcStatutoryCurrency","tPosting.tcTemplateCode","tPosting.tlSaveAsTemplate","tPosting.tgSharedCompanyId","tPosting.tiYearForNbr","tPosting.tlIsAddGLNbr","tPosting.tiOriginVoucher","tPosting.tgOriginPostingId","tPosting.tcJournalCode","tPosting.tcLayerTypeCode","tPosting.tcJournalTypeCode","tPosting.tcUsrLogin","tPosting.tcPeriodTypeCode","tPosting.tcReportingJournalCode","tPosting.tlJournalAccessAllowed","tPostingLine.PostingLine_ID","tPostingLine.PostingLineSequence","tPostingLine.PostingLineText","tPostingLine.PostingLineDebitLC"," tPostingLine.PostingLineDebitTC "," tPostingLine.PostingLineDebitCC "," tPostingLine.PostingLineDebitPC "," tPostingLine.PostingLineCreditLC "," tPostingLine.PostingLineCreditTC ","tPostingLine.PostingLineCreditCC","tPostingLine.PostingLineCreditPC","tPostingLine.PostingLineIsProjPosting","tPostingLine.PostingLineQTY","tPostingLine.PostingLineProjectText","tPostingLine.PostingLineCostCentreText","tPostingLine.PostingLineSafText","tPostingLine.PostingLineExchangeRate","tPostingLine.PostingLineRateScale","tPostingLine.PostingLineCCRate","tPostingLine.PostingLineCCScale","tPostingLine.PostingYearPeriod","tPostingLine.PostingDate","tPostingLine.PostingLineCrossExternRef","tPostingLine.PostingLineOriginLineNbr","tPostingLine.PostingLineMirrorRef","tPostingLine.PostingLineMirrorType","tPostingLine.PostingLineAddGLNbr","tPostingLine.PostingLineGrossIncAccRef","tPostingLine.PostingLineAddGLNbrDate","tPostingLine.PostingLineLegalDocNbr","tPostingLine.tcProjectDescription","tPostingLine.tcGLCode","tPostingLine.tlPostingLineIsLocalCurrency","tPostingLine.tgVatPostID","tPostingLine.tcGLDescription","tPostingLine.tlGLIsAutomaticAccount","tPostingLine.tcGLTypeCode","tPostingLine.tcUnitCode","tPostingLine.tcAllocationType","tPostingLine.tcAllocationKey","tPostingLine.tcAllocationPostingLine","tPostingLine.tcIntercoBusinessRelationCode","tPostingLine.tcCurrencyCode","tPostingLine.tcDivisionCode","tPostingLine.tcCostCentreCode","tPostingLine.tcProjectCode","tPostingLine.tlGLIsDebitAccount","tPostingLine.tcCrossCompanyCurrencyCode","tPostingLine.tcCrossCompanyGLCode","tPostingLine.tcCrossCompanyIntercoCode","tPostingLine.tcCrossCompanyCode","tPostingLine.tcDivisionDescription","tPostingLine.tlLinkedCrCyDaemonReqExists","tPostingLine.tcCostCentreDescription","tPostingLine.tlSkipCOAValForPeriodCosting","tPostingLine.tcConsumptionVatCode","tPostingLine.tlGLIsConsumptionVat","tPostingLine.tcConsumptionVatDomainCode","tPostingLine.tcConsumptionVatInOut","tPostingSaf.PostingSaf_ID","tPostingSaf.PostingSafParentType","tPostingSaf.PostingSafInputSequence","tPostingSaf.tcSafCode","tPostingSaf.tcSafConceptCode","tPostingSaf.tcSafStructureCode","tPostingVat.PostingVat_ID","tPostingVat.PostingVatBaseDebitLC","tPostingVat.PostingVatBaseDebitTC","tPostingVat.PostingVatBaseDebitCC","tPostingVat.PostingVatBaseCreditLC","tPostingVat.PostingVatBaseCreditTC","tPostingVat.PostingVatBaseCreditCC","tPostingVat.PostingVatExchangeRate","tPostingVat.PostingVatRateScale","tPostingVat.PostingVatInOut","tPostingVat.PostingVatTaxPointDate","tPostingVat.PostingVatTaxTransType","tPostingVat.PostingVatTransType","tPostingVat.PostingVatTaxDebitLC","tPostingVat.PostingVatTaxDebitCC","tPostingVat.PostingVatTaxDebitTC","tPostingVat.PostingVatTaxCreditLC","tPostingVat.PostingVatTaxCreditCC","tPostingVat.PostingVatTaxCreditTC","tPostingVat.PostingVatTaxIDFeder","tPostingVat.PostingVatTaxIDState","tPostingVat.PostingVatTaxIDMisc1","tPostingVat.PostingVatTaxIDMisc2","tPostingVat.PostingVatTaxIDMisc3","tPostingVat.PostingVatOwnTaxIDFeder","tPostingVat.PostingVatOwnTaxIDState","tPostingVat.PostingVatOwnTaxIDMisc1","tPostingVat.PostingVatOwnTaxIDMisc2","tPostingVat.PostingVatOwnTaxIDMisc3","tPostingVat.PostingVatOwnTaxDeclarat","tPostingVat.PostingVatIsReverseCharge","tPostingVat.PostingVatIsAbsRet","tPostingVat.PostingVatIsSuspDel","tPostingVat.TxtyTaxType","tPostingVat.TxclTaxCls","tPostingVat.TxuTaxUsage","tPostingVat.TxenvTaxEnv","tPostingVat.FromTxzTaxZone","tPostingVat.ToTxzTaxZone","tPostingVat.tcCurrencyCode","tPostingVat.tdFullDebitTC","tPostingVat.tdFullCreditTC","tPostingVat.tdTotalVatDebitTC","tPostingVat.tdTotalVatCreditTC","tPostingVat.tcVatCode","tPostingVat.tcVatDescription","tPostingVat.tcDomainCode","tPostingVat.tcVatInOut","tPostingVat.tcVatGroupCode","tPostingVatDelay.PostingVatDelay_ID","tPostingVatDelay.PostingVatDelayBaseDebLC","tPostingVatDelay.PostingVatDelayBaseCredLC","tPostingVatDelay.PostingVatDelayBaseDebTC","tPostingVatDelay.PostingVatDelayBaseCredTC","tPostingVatDelay.PostingVatDelayBaseDebCC","tPostingVatDelay.PostingVatDelayBaseCredCC","tPostingVatDelay.PostingVatDelayTaxPntDate","tPostingVatDelay.PostingVatDelayVATBalLC","tPostingVatDelay.PostingVatDelayVATOrigLC","tPostingVatDelay.PostingVatDelayIsOpen","tPostingVatDelay.PostingVatDelayExchRate","tPostingVatDelay.PostingVatDelayRateScale","tPostingVatDelay.PostingVatDelayTaxIDFeder","tPostingVatDelay.PostingVatDelayTaxIDState","tPostingVatDelay.PostingVatDelayTaxIDMisc1","tPostingVatDelay.PostingVatDelayTaxIDMisc2","tPostingVatDelay.PostingVatDelayTaxIDMisc3","tPostingVatDelay.PostingVatDelayOwnTaxIDFed","tPostingVatDelay.PostingVatDelayOwnTaxIDSt","tPostingVatDelay.PostingVatDelayOwnTaxIDM1","tPostingVatDelay.PostingVatDelayOwnTaxIDM2","tPostingVatDelay.PostingVatDelayOwnTaxIDM3","tPostingVatDelay.PostingVatDelayOwnTaxDecl","tPostingVatDelay.tcVatCode","tPostingVatDelay.tcVatDescription","tPostingVatDelay.tdFullDebitTC","tPostingVatDelay.tdFullCreditTC","tPostingVatDelay.tdTotalVatDebitTC","tPostingVatDelay.tdTotalVatCreditTC","tPostingVatDelay.tcCurrencyCode","tPostingVatDelay.tcDomainCode","tPostingVatDelay.tcVatInOut","tPostingWHT.PostingWHT_ID","tPostingWHT.PostingWHTBaseDebitLC","tPostingWHT.PostingWHTBaseDebitTC","tPostingWHT.PostingWHTBaseDebitCC","tPostingWHT.PostingWHTBaseCreditLC","tPostingWHT.PostingWHTBaseCreditTC","tPostingWHT.PostingWHTBaseCreditCC","tPostingWHT.PostingWHTExchangeRate","tPostingWHT.PostingWHTRateScale","tPostingWHT.PostingWHTInOut","tPostingWHT.PostingWHTTaxPointDate","tPostingWHT.PostingWHTTaxTransType","tPostingWHT.PostingWHTTransType","tPostingWHT.PostingWHTTaxDebitLC","tPostingWHT.PostingWHTTaxDebitCC","tPostingWHT.PostingWHTTaxDebitTC","tPostingWHT.PostingWHTTaxCreditLC","tPostingWHT.PostingWHTTaxCreditCC","tPostingWHT.PostingWHTTaxCreditTC","tPostingWHT.PostingWHTTaxIDFeder","tPostingWHT.PostingWHTTaxIDState","tPostingWHT.PostingWHTTaxIDMisc1","tPostingWHT.PostingWHTTaxIDMisc2","tPostingWHT.PostingWHTTaxIDMisc3","tPostingWHT.PostingWHTOwnTaxIDFeder","tPostingWHT.PostingWHTOwnTaxIDState","tPostingWHT.PostingWHTOwnTaxIDMisc1","tPostingWHT.PostingWHTOwnTaxIDMisc2","tPostingWHT.PostingWHTOwnTaxIDMisc3","tPostingWHT.PostingWHTOwnTaxDeclarat","tPostingWHT.PostingWHTTxtyTaxType","tPostingWHT.PostingWHTTxclTaxCls","tPostingWHT.PostingWHTTxuTaxUsage","tPostingWHT.PostingWHTTxenvTaxEnv","tPostingWHT.PostingWHTFromTxzTaxZone","tPostingWHT.PostingWHTToTxzTaxZone","tPostingWHT.tcCurrencyCode","tPostingWHT.tcVatCode","tPostingWHT.tdFullDebitTC","tPostingWHT.tdFullCreditTC","tPostingWHT.tcDomainCode","tPostingWHT.tcVatInOut"],
            ]
        ];
		
		$filter = [
            'start_date'=>$this->input->get('start_date'),
            'end_date'=>$this->input->get('end_date'),
			'month'=>$this->input->get('month'),
			'branch_id'=>$this->input->get('branch_id'),
			'upload'=>1,
			'status'=>0,
			//'type'=>$this->input->get('type'),
			'check'=>$this->input->post('check')
        ];
		
		//$filter = $this->input->get();
        //$filter['check'] = $this->input->post('check');
        //$filter['status'] = 0;
        //$filter['upload'] = 1;
		
        switch($type){
            case 'cabang': $filter['type'] = $this->JournalModel->filter_type['cabang']; break;
            case 'ho': $filter['type'] = $this->JournalModel->filter_type['ho']; break;
            case 'notadebet': $filter['type'] = $this->JournalModel->filter_type['notadebet']; break;
        }
		
		if (empty($is_unupload))
		{
			$data['journal'] = $this->JournalModel->get($filter);
			
			$dataExport = [];
		
			foreach($data['journal'] as $k=>$v){
				$dataExport[$v['branch_name']][] = $v;
			}

			// $this->excel($data);
			
			$this->load->library('zip');
			foreach($dataExport as $branch_name=>$value){
				$data['title'] = $branch_name.'.xls';
				$data['data'] = $value;
				$data['temp'] = tempnam(FCPATH.'/application/tmp', 'j_');
				if($this->excel($data))
					continue;
				$this->zip->read_file($data['temp'],$data['title']);
			}
		}
		
        //$this->db->where_in('journal_id',$filter['check'])->update('tbl_journal',['status'=>1]);
		
		$branch = $this->MasterModel->getBranchArray();
		if(!empty($branch)){
			$branch = array_column($branch,'id');
		}
		
		if(!empty($filter['type'])){
			if(is_array($filter['type'])){
				$this->db->where_in('tj.type',$filter['type']);
			}else{
				$this->db->where('tj.type',$filter['type']);
			}
		}
		if(!empty($filter['check'])){
			if(is_array($filter['check'])){
				$this->db->where_in('tj.journal_id',$filter['check']);
			}else{
				$this->db->where('tj.journal_id',$filter['check']);
			}
		}
		if(!empty($filter['month'])){
			$filter['year'] = explode('/',$filter['month'])[0];
			$filter['month'] = explode('/',$filter['month'])[1];
			$this->db->where('tj.year',$filter['year']);
			$this->db->where('tj.month',$filter['month']);
		}
		if(!empty($filter['start_date'])){
			$this->db->where('tj.date>=',date('Y-m-d',strtotime($filter['start_date'])));
		}
		if(!empty($filter['end_date'])){
			$this->db->where('tj.date<=',date('Y-m-d',strtotime($filter['end_date'])));
		}
		if(!empty($filter['branch_id'])){
			$this->db->where('tj.branch_id',$filter['branch_id']);
		}else if(!empty($branch)){
			$this->db->where_in('tj.branch_id',$branch);
		}
		
		if (empty($is_unupload))
		{
			$this->db->update('tbl_journal tj',['status'=>1]);
			$this->zip->download(date('Y-m').'.zip');
		}
		
		else
		$this->db->update('tbl_journal tj',['status'=>0]);
    }
	
	public function get_upload_cabang()
	{
		$this->load->helper('file');
		
		$folder = APPPATH.'/tmp/journal';
		
		if (!is_dir($folder))
		mkdir($folder, 0777, true);
		
		delete_files($folder, true);
		
		$filter = [
            'start_date'=>$this->input->get('start_date'),
            'end_date'=>$this->input->get('end_date'),
			'month'=>$this->input->get('month'),
			'branch_id'=>$this->input->get('branch_id'),
			'upload'=>1,
			'status'=>0,
			'type'=>$this->JournalModel->filter_type['cabang'],
			'check'=>$this->input->post('check')
        ];
		
		$data = $this->JournalModel->get_branch($filter);
		$total = count($data);
		
		echo json_encode(['status'=>'success','data'=>$data,'total'=>$total]);
    }
	
	public function upload_cabang($branch_id)
	{
        $data = [
            'header' => [
                ["Record ID","Voucher","Posting Date","Sys Date","Value Date","Description","Second Description","Business Relation (IC Posting)","External Invoice Reference","Parent Text","GL Period","Year","GL Cal Yr/GL Pd","External Origin","Origin Ref","Origin Doc","Origin Pay Type","Origin Trans Type","Origin Daybook Code","Origin Daybook Number","Batch Number","Address Code","Original Posting Reference","Is Replacement","Is Reversal","Correction","Zero Value Allowed","Skip Auto Assign BC","Sequence Number","Additional GL Numbering Date","Additional GL Numbering Reversal Date","Verify Status","Verify Comments","Last Verified Date","Last Verified Time","Approve Status","Approve Comments","Last Approved Date","Last Approved Time","Mirroring Reference","Automatic Reversal","Automatic Reversal Type","Reversal Posting Date","Bank Import Reference","Correction","Creation Date","Creation Time","Transient Reference","Base Currency","Statutory Currency","Template Code","Save As Template","Shared Company ID","Year for Calculating GL Numbering","Additional GL Numbering Enabled","Original Voucher","Original Posting ID","Daybook Code","Type","Daybook Type","Login","Period Type","Reporting Daybook Code","Daybook Access Allowed","Record ID","Seq","Description","BC Debit"," TC Debit "," SC Debit "," pc Debit "," BC Credit "," TC Credit ","SC Credit","pc Credit","Proj","Quantity","Prj","Cost Center","SAF","Exchange Rate","Scale Factor","SC Exchange Rate","SC Scale Factor","GL Cal Yr/GL Pd","Posting Date","Ext Reference (Cross-Cy)","Origin Line No","Mirroring Reference","Mirroring Type","Additional Sequence Number","Gross Income Accounting Reference","Additional Sequence Date","Legal Document","Description","GL Account","Base Curr","Tax","GL Description","Auto","GL Type","UM","Allocation","Allocation Key","Open Item Posting","Intercompany Code","Trans Curr","Sub-Account Code","Cost Center Code","Project Code","Debit/Credit","Currency (Cross-Cy)","GL (Cross-Cy)","Interco-Code (Cross-Cy)","Cross-Company Code","Sub Account Description","Cr Cy Posting Linked To Daemon","Cost Centre Description","Skip COA Val for PC","Consumption Tax Code","GLIsConsumptionVat","Consumption Tax Domain","Consumption Tax In/Out","Record ID","Parent Type","Seq","SAF Code","SAF Concept Code","Structure","Record ID","BC Base Debit","TC Base Debit","SC Base Debit","BC Base Credit","TC Base Credit","SC Base Credit","Rate","Scale Factor","In/Out","Tax Date","Tax Trans Type","Trans Type","BC Tax Debit","SC Tax Debit","TC Tax Debit","BC Tax Credit","SC Tax Credit","TC Tax Credit","Federal Tax","State Tax","Misc Tax 1","Misc Tax 2","Misc Tax 3","Own Federal Tax","Own State Tax","Own Misc Tax 1","Own Misc Tax 1","Own Misc Tax 3","Own Declaration Tax","Reverse Charge","Absorbed Retained","Susp/Del","Tax Type","Tax Class","Tax Usage","Tax Env","From Tax Zone","To Tax Zone","Curr","TC Debit","TC Credit","TC Tax Debit","TC Tax Credit","Tax Code","Description","Domain","In/Out","Tax Group Code","Record ID","BC Base Debit","BC Base Credit","TC Base Debit","TC Base Credit","SC Base Debit","SC Base Credit","Tax Point Date","BC Tax Balance","BC Tax Original","Open","Rate","Scale Factor","Federal Tax ID","State","Misc 1","Misc 2","Misc 3","Own Federal Tax ID","Own State Tax ID","Own Misc 1 ID","Own Misc 2 ID","Own Misc 3 ID","Own Tax Decalaration","Tax Code","Description","TC Debit","TC Credit","TC Tax Debit","TC Tax Credit","Curr","Domain","In/Out","Record ID","BC Base Debit","TC Base Debit","SC Base Debit","BC Base Credit","TC Base Credit","SC Base Credit","Rate","Scale Factor","In/Out","Tax Date","Tax Trans Type","Trans Type","BC Tax Debit","SC Tax Debit","TC Tax Debit","BC Tax Credit","SC Tax Credit","TC Tax Credit","Federal Tax","State Tax","Misc Tax 1","Misc Tax 2","Misc Tax 3","Own Federal Tax","Own State Tax","Own Misc Tax 1","Own Misc Tax 1","Own Misc Tax 3","Own Declaration Tax","Tax Type","Tax Class","Tax Usage","Tax Env","From Tax Zone","To Tax Zone","CurrencyCode","Tax Code","TC Debit","TC Credit","Domain Code","In/Out"],
                ["tPosting.Posting_ID","tPosting.PostingVoucher","tPosting.PostingDate","tPosting.PostingSystemDate","tPosting.PostingValueDate","tPosting.PostingText","tPosting.PostingSecondText","tPosting.PostingBusinessRelationTxt","tPosting.PostingInvoiceReferenceTxt","tPosting.PostingParentText","tPosting.PostingPeriod","tPosting.PostingYear","tPosting.PostingYearPeriod","tPosting.PostingOriginIsExternal","tPosting.PostingOriginReference","tPosting.PostingOriginDocument","tPosting.PostingOriginDocumentType","tPosting.PostingOriginTransType","tPosting.PostingOriginDaybookCode","tPosting.PostingOriginDaybookNumber","tPosting.PostingBatchNumber","tPosting.PostingOriginAddressCode","tPosting.PostingOriginatorReference","tPosting.PostingIsReplacement","tPosting.PostingIsReversing","tPosting.PostingIsReversingBySign","tPosting.PostingIsZeroValueAllowed","tPosting.PostingIsSkipAutoAssignLC","tPosting.PostingAddGLNbr","tPosting.PostingAddGLNbrDate","tPosting.PostingAddGLNbrRevDate","tPosting.PostingVerifyStatus","tPosting.PostingVerifyComments","tPosting.PostingVerifiedDate","tPosting.PostingVerifiedTime","tPosting.PostingApproveStatus","tPosting.PostingApproveComments","tPosting.PostingApprovedDate","tPosting.PostingApprovedTime","tPosting.PostingMirrorRef","tPosting.PostingIsAutoReversal","tPosting.PostingAutoReversalType","tPosting.PostingAutoReversalDate","tPosting.PostingBankImpRef","tPosting.PostingIsCorrection","tPosting.PostingCreationDate","tPosting.PostingCreationTimeString","tPosting.PostingTransientRef","tPosting.tcLocalCurrency","tPosting.tcStatutoryCurrency","tPosting.tcTemplateCode","tPosting.tlSaveAsTemplate","tPosting.tgSharedCompanyId","tPosting.tiYearForNbr","tPosting.tlIsAddGLNbr","tPosting.tiOriginVoucher","tPosting.tgOriginPostingId","tPosting.tcJournalCode","tPosting.tcLayerTypeCode","tPosting.tcJournalTypeCode","tPosting.tcUsrLogin","tPosting.tcPeriodTypeCode","tPosting.tcReportingJournalCode","tPosting.tlJournalAccessAllowed","tPostingLine.PostingLine_ID","tPostingLine.PostingLineSequence","tPostingLine.PostingLineText","tPostingLine.PostingLineDebitLC"," tPostingLine.PostingLineDebitTC "," tPostingLine.PostingLineDebitCC "," tPostingLine.PostingLineDebitPC "," tPostingLine.PostingLineCreditLC "," tPostingLine.PostingLineCreditTC ","tPostingLine.PostingLineCreditCC","tPostingLine.PostingLineCreditPC","tPostingLine.PostingLineIsProjPosting","tPostingLine.PostingLineQTY","tPostingLine.PostingLineProjectText","tPostingLine.PostingLineCostCentreText","tPostingLine.PostingLineSafText","tPostingLine.PostingLineExchangeRate","tPostingLine.PostingLineRateScale","tPostingLine.PostingLineCCRate","tPostingLine.PostingLineCCScale","tPostingLine.PostingYearPeriod","tPostingLine.PostingDate","tPostingLine.PostingLineCrossExternRef","tPostingLine.PostingLineOriginLineNbr","tPostingLine.PostingLineMirrorRef","tPostingLine.PostingLineMirrorType","tPostingLine.PostingLineAddGLNbr","tPostingLine.PostingLineGrossIncAccRef","tPostingLine.PostingLineAddGLNbrDate","tPostingLine.PostingLineLegalDocNbr","tPostingLine.tcProjectDescription","tPostingLine.tcGLCode","tPostingLine.tlPostingLineIsLocalCurrency","tPostingLine.tgVatPostID","tPostingLine.tcGLDescription","tPostingLine.tlGLIsAutomaticAccount","tPostingLine.tcGLTypeCode","tPostingLine.tcUnitCode","tPostingLine.tcAllocationType","tPostingLine.tcAllocationKey","tPostingLine.tcAllocationPostingLine","tPostingLine.tcIntercoBusinessRelationCode","tPostingLine.tcCurrencyCode","tPostingLine.tcDivisionCode","tPostingLine.tcCostCentreCode","tPostingLine.tcProjectCode","tPostingLine.tlGLIsDebitAccount","tPostingLine.tcCrossCompanyCurrencyCode","tPostingLine.tcCrossCompanyGLCode","tPostingLine.tcCrossCompanyIntercoCode","tPostingLine.tcCrossCompanyCode","tPostingLine.tcDivisionDescription","tPostingLine.tlLinkedCrCyDaemonReqExists","tPostingLine.tcCostCentreDescription","tPostingLine.tlSkipCOAValForPeriodCosting","tPostingLine.tcConsumptionVatCode","tPostingLine.tlGLIsConsumptionVat","tPostingLine.tcConsumptionVatDomainCode","tPostingLine.tcConsumptionVatInOut","tPostingSaf.PostingSaf_ID","tPostingSaf.PostingSafParentType","tPostingSaf.PostingSafInputSequence","tPostingSaf.tcSafCode","tPostingSaf.tcSafConceptCode","tPostingSaf.tcSafStructureCode","tPostingVat.PostingVat_ID","tPostingVat.PostingVatBaseDebitLC","tPostingVat.PostingVatBaseDebitTC","tPostingVat.PostingVatBaseDebitCC","tPostingVat.PostingVatBaseCreditLC","tPostingVat.PostingVatBaseCreditTC","tPostingVat.PostingVatBaseCreditCC","tPostingVat.PostingVatExchangeRate","tPostingVat.PostingVatRateScale","tPostingVat.PostingVatInOut","tPostingVat.PostingVatTaxPointDate","tPostingVat.PostingVatTaxTransType","tPostingVat.PostingVatTransType","tPostingVat.PostingVatTaxDebitLC","tPostingVat.PostingVatTaxDebitCC","tPostingVat.PostingVatTaxDebitTC","tPostingVat.PostingVatTaxCreditLC","tPostingVat.PostingVatTaxCreditCC","tPostingVat.PostingVatTaxCreditTC","tPostingVat.PostingVatTaxIDFeder","tPostingVat.PostingVatTaxIDState","tPostingVat.PostingVatTaxIDMisc1","tPostingVat.PostingVatTaxIDMisc2","tPostingVat.PostingVatTaxIDMisc3","tPostingVat.PostingVatOwnTaxIDFeder","tPostingVat.PostingVatOwnTaxIDState","tPostingVat.PostingVatOwnTaxIDMisc1","tPostingVat.PostingVatOwnTaxIDMisc2","tPostingVat.PostingVatOwnTaxIDMisc3","tPostingVat.PostingVatOwnTaxDeclarat","tPostingVat.PostingVatIsReverseCharge","tPostingVat.PostingVatIsAbsRet","tPostingVat.PostingVatIsSuspDel","tPostingVat.TxtyTaxType","tPostingVat.TxclTaxCls","tPostingVat.TxuTaxUsage","tPostingVat.TxenvTaxEnv","tPostingVat.FromTxzTaxZone","tPostingVat.ToTxzTaxZone","tPostingVat.tcCurrencyCode","tPostingVat.tdFullDebitTC","tPostingVat.tdFullCreditTC","tPostingVat.tdTotalVatDebitTC","tPostingVat.tdTotalVatCreditTC","tPostingVat.tcVatCode","tPostingVat.tcVatDescription","tPostingVat.tcDomainCode","tPostingVat.tcVatInOut","tPostingVat.tcVatGroupCode","tPostingVatDelay.PostingVatDelay_ID","tPostingVatDelay.PostingVatDelayBaseDebLC","tPostingVatDelay.PostingVatDelayBaseCredLC","tPostingVatDelay.PostingVatDelayBaseDebTC","tPostingVatDelay.PostingVatDelayBaseCredTC","tPostingVatDelay.PostingVatDelayBaseDebCC","tPostingVatDelay.PostingVatDelayBaseCredCC","tPostingVatDelay.PostingVatDelayTaxPntDate","tPostingVatDelay.PostingVatDelayVATBalLC","tPostingVatDelay.PostingVatDelayVATOrigLC","tPostingVatDelay.PostingVatDelayIsOpen","tPostingVatDelay.PostingVatDelayExchRate","tPostingVatDelay.PostingVatDelayRateScale","tPostingVatDelay.PostingVatDelayTaxIDFeder","tPostingVatDelay.PostingVatDelayTaxIDState","tPostingVatDelay.PostingVatDelayTaxIDMisc1","tPostingVatDelay.PostingVatDelayTaxIDMisc2","tPostingVatDelay.PostingVatDelayTaxIDMisc3","tPostingVatDelay.PostingVatDelayOwnTaxIDFed","tPostingVatDelay.PostingVatDelayOwnTaxIDSt","tPostingVatDelay.PostingVatDelayOwnTaxIDM1","tPostingVatDelay.PostingVatDelayOwnTaxIDM2","tPostingVatDelay.PostingVatDelayOwnTaxIDM3","tPostingVatDelay.PostingVatDelayOwnTaxDecl","tPostingVatDelay.tcVatCode","tPostingVatDelay.tcVatDescription","tPostingVatDelay.tdFullDebitTC","tPostingVatDelay.tdFullCreditTC","tPostingVatDelay.tdTotalVatDebitTC","tPostingVatDelay.tdTotalVatCreditTC","tPostingVatDelay.tcCurrencyCode","tPostingVatDelay.tcDomainCode","tPostingVatDelay.tcVatInOut","tPostingWHT.PostingWHT_ID","tPostingWHT.PostingWHTBaseDebitLC","tPostingWHT.PostingWHTBaseDebitTC","tPostingWHT.PostingWHTBaseDebitCC","tPostingWHT.PostingWHTBaseCreditLC","tPostingWHT.PostingWHTBaseCreditTC","tPostingWHT.PostingWHTBaseCreditCC","tPostingWHT.PostingWHTExchangeRate","tPostingWHT.PostingWHTRateScale","tPostingWHT.PostingWHTInOut","tPostingWHT.PostingWHTTaxPointDate","tPostingWHT.PostingWHTTaxTransType","tPostingWHT.PostingWHTTransType","tPostingWHT.PostingWHTTaxDebitLC","tPostingWHT.PostingWHTTaxDebitCC","tPostingWHT.PostingWHTTaxDebitTC","tPostingWHT.PostingWHTTaxCreditLC","tPostingWHT.PostingWHTTaxCreditCC","tPostingWHT.PostingWHTTaxCreditTC","tPostingWHT.PostingWHTTaxIDFeder","tPostingWHT.PostingWHTTaxIDState","tPostingWHT.PostingWHTTaxIDMisc1","tPostingWHT.PostingWHTTaxIDMisc2","tPostingWHT.PostingWHTTaxIDMisc3","tPostingWHT.PostingWHTOwnTaxIDFeder","tPostingWHT.PostingWHTOwnTaxIDState","tPostingWHT.PostingWHTOwnTaxIDMisc1","tPostingWHT.PostingWHTOwnTaxIDMisc2","tPostingWHT.PostingWHTOwnTaxIDMisc3","tPostingWHT.PostingWHTOwnTaxDeclarat","tPostingWHT.PostingWHTTxtyTaxType","tPostingWHT.PostingWHTTxclTaxCls","tPostingWHT.PostingWHTTxuTaxUsage","tPostingWHT.PostingWHTTxenvTaxEnv","tPostingWHT.PostingWHTFromTxzTaxZone","tPostingWHT.PostingWHTToTxzTaxZone","tPostingWHT.tcCurrencyCode","tPostingWHT.tcVatCode","tPostingWHT.tdFullDebitTC","tPostingWHT.tdFullCreditTC","tPostingWHT.tcDomainCode","tPostingWHT.tcVatInOut"],
            ]
        ];
		
		$filter = [
            'start_date'=>$this->input->get('start_date'),
            'end_date'=>$this->input->get('end_date'),
			'month'=>$this->input->get('month'),
			//'branch_id'=>$this->input->get('branch_id'),
			'branch_id'=>$branch_id,
			'upload'=>1,
			'status'=>0,
			'type'=>$this->JournalModel->filter_type['cabang'],
			'check'=>$this->input->post('check')
        ];

		$data['journal'] = $this->JournalModel->get($filter);
		
		$dataExport = [];
	
		foreach($data['journal'] as $k=>$v){
			$dataExport[$v['branch_name']][] = $v;
		}

		//$this->excel($data);
		
		$folder = APPPATH.'/tmp/journal';
		
		$this->load->library('zip');
		foreach($dataExport as $branch_name=>$value){
			$data['title'] = $branch_name.'.xls';
			$data['data'] = $value;
			//$data['temp'] = tempnam($folder, 'j_');
			$data['temp'] = $folder.'/'.$data['title'];
			if($this->excel($data))
				continue;
			//$this->zip->read_file($data['temp'],$data['title']);
		}
		
		echo json_encode(['status'=>'success']);
    }
	
	public function finish_upload_cabang()
	{
		$filter = [
            'start_date'=>$this->input->get('start_date'),
            'end_date'=>$this->input->get('end_date'),
			'month'=>$this->input->get('month'),
			'branch_id'=>$this->input->get('branch_id'),
			'upload'=>1,
			'status'=>0,
			'type'=>$this->JournalModel->filter_type['cabang'],
			'check'=>$this->input->post('check')
        ];
		
		$branch = $this->MasterModel->getBranchArray();
		if(!empty($branch)){
			$branch = array_column($branch,'id');
		}
		
		if(!empty($filter['type'])){
			if(is_array($filter['type'])){
				$this->db->where_in('tj.type',$filter['type']);
			}else{
				$this->db->where('tj.type',$filter['type']);
			}
		}
		if(!empty($filter['check'])){
			if(is_array($filter['check'])){
				$this->db->where_in('tj.journal_id',$filter['check']);
			}else{
				$this->db->where('tj.journal_id',$filter['check']);
			}
		}
		if(!empty($filter['month'])){
			$filter['year'] = explode('/',$filter['month'])[0];
			$filter['month'] = explode('/',$filter['month'])[1];
			$this->db->where('tj.year',$filter['year']);
			$this->db->where('tj.month',$filter['month']);
		}
		if(!empty($filter['start_date'])){
			$this->db->where('tj.date>=',date('Y-m-d',strtotime($filter['start_date'])));
		}
		if(!empty($filter['end_date'])){
			$this->db->where('tj.date<=',date('Y-m-d',strtotime($filter['end_date'])));
		}
		if(!empty($filter['branch_id'])){
			$this->db->where('tj.branch_id',$filter['branch_id']);
		}else if(!empty($branch)){
			$this->db->where_in('tj.branch_id',$branch);
		}
		
		$this->db->update('tbl_journal tj',['status'=>1]);
		
		$folder = APPPATH.'/tmp/journal';
		$this->load->library('zip');
		$this->zip->compression_level = 9;
		$this->zip->read_dir($folder, false);
		$this->zip->download(date('Y-m-d H.i.s').'.zip');
    }
	
    private function excel($data){
        $object = new PHPExcel();
        $object->setActiveSheetIndex(0);
        $row_count = 1;
        foreach(range('A','IS') as $columnDimension){
            $object->getActiveSheet()->getColumnDimension($columnDimension)->setAutoSize(true);
        }
		$object->getActiveSheet()->getStyle('A1:IS1')->getFont()->setBold(true);
		$object->getActiveSheet()->getStyle('A2:IS2')->getFont()->setItalic(true);
        foreach($data['header'] as $key=>$field){
            if(is_array($field)){
                foreach($field as $colIndex => $col) {
                    $object->getActiveSheet()->setCellValueByColumnAndRow($colIndex, $row_count, $col);
                }
                $row_count++;
            }else{
                $object->getActiveSheet()->setCellValueByColumnAndRow($key, $row_count, $field);
            }
        }
        foreach($data['data'] as $m=>$v){
            foreach($v['detail'] as $n=>$w){
                if($w['sequence']==1){
                     $object->getActiveSheet()->setCellValueByColumnAndRow(2, $row_count, date('d/m/Y',strtotime($v['date'])));
					 $object->getActiveSheet()->getStyleByColumnAndRow(2, $row_count)->getNumberFormat()->setFormatCode('dd/mm/yyyy');
					 
                     $object->getActiveSheet()->setCellValueByColumnAndRow(3, $row_count, date('d/m/Y',strtotime($v['date'])));
					 $object->getActiveSheet()->getStyleByColumnAndRow(3, $row_count)->getNumberFormat()->setFormatCode('dd/mm/yyyy');
					 
                     $object->getActiveSheet()->setCellValueByColumnAndRow(5, $row_count, substr($v['description'], 0, 40));
                     $object->getActiveSheet()->setCellValueByColumnAndRow(6, $row_count, $v['no_doc']);
                     $object->getActiveSheet()->setCellValueByColumnAndRow(10, $row_count, date('m',strtotime($v['date'])));
                     $object->getActiveSheet()->setCellValueByColumnAndRow(11, $row_count, date('Y',strtotime($v['date'])));
                     //$object->getActiveSheet()->setCellValueByColumnAndRow(57, $row_count, $v['journal_code']);
					 $object->getActiveSheet()->setCellValueByColumnAndRow(57, $row_count, 'GL-OFC');
                }
                $object->getActiveSheet()->setCellValueByColumnAndRow(65, $row_count, $w['sequence']);
                $object->getActiveSheet()->setCellValueByColumnAndRow(66, $row_count, substr($v['description'], 0, 40));
                $object->getActiveSheet()->setCellValueByColumnAndRow(67, $row_count, $w['debit']);
                $object->getActiveSheet()->setCellValueByColumnAndRow(68, $row_count, $w['debit']);
                $object->getActiveSheet()->setCellValueByColumnAndRow(71, $row_count, $w['credit']);
                $object->getActiveSheet()->setCellValueByColumnAndRow(72, $row_count, $w['credit']);
                $object->getActiveSheet()->setCellValueByColumnAndRow(80, $row_count, $w['exchange_rate']);
                $object->getActiveSheet()->setCellValueByColumnAndRow(95, $row_count, $w['gl_code']);
                //$object->getActiveSheet()->setCellValueByColumnAndRow(106, $row_count, $w['currency_code']);
				$object->getActiveSheet()->setCellValueByColumnAndRow(106, $row_count, 'IDR');
                $object->getActiveSheet()->setCellValueByColumnAndRow(107, $row_count, $w['division_code']);
                $object->getActiveSheet()->setCellValueByColumnAndRow(108, $row_count, $w['cost_center_code']);
                //$object->getActiveSheet()->setCellValueByColumnAndRow(109, $row_count, $v['project']);
				$object->getActiveSheet()->setCellValueByColumnAndRow(109, $row_count, '');
                $row_count++;
            }
        }
        $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
        $object_writer->save($data['temp']);
    }
    public function __destruct(){
        array_map('unlink', glob(FCPATH.'/application/tmp/j_*'));
    }
	
	public function getMyJournal($type, $uploaded='')
    {
        $draw = $this->input->get('draw');
        $limit = $this->input->get('length');
        $offset = $this->input->get('start');
		
		$filter = [
            'start_date'=>$this->input->get('start_date'),
            'end_date'=>$this->input->get('end_date'),
			'month'=>$this->input->get('month'),
			'branch_id'=>$this->input->get('branch_id'),
			'upload'=>$this->input->get('upload'),
			'status'=>$this->input->get('status'),
			'type'=>$this->input->get('type')
        ];
		
		$result = $this->JournalModel->getDynamic($limit,$offset,$filter);
		$data = $result[0];
		$total = $result[1];
        
        $array_output_data = array();
		
        foreach ($data as $key => $val)
        {
			$checkbox = '<input type="checkbox" name="check[]" value="'.$val['id'].'">';
			$branch = $val['branch_name'];
			$tgl_bkk = toLocaleDateString($val['date']);
			$sub_register = $val['sub_register'];
			$no_doc = $val['no_doc'];
			$k_rek = $sub_register;
			$debit = '';
			$kredit = '';
			$no_perkiraan = implode('<br>',arr_comb_same_index(array_column($val['detail'],'gl_code'),array_column($val['detail'],'division_code'),"."));
			$cc = implode('<br>',array_column($val['detail'],'cost_center_code'));
			$debit2 = '';
			$kredit2 = '';
			$keterangan = $val['description'];
			$project = $val['project'];
			
			if ($type == 'cabang' && empty($uploaded))
			{
				if(in_array($val['type'],[1,4,5,7,8]))
				{
					$debit = implode('<br>',arr_number_format(array_column($val['detail'],'debit')));
					$kredit = implode('<br>',arr_number_format(array_column($val['detail'],'credit')));
				}
				
				if(in_array($val['type'],[2,3,9,10,11,12]))
				{
					$debit2 = implode('<br>',arr_number_format(array_column($val['detail'],'debit')));
					$kredit2 = implode('<br>',arr_number_format(array_column($val['detail'],'credit')));
				}
				
				array_push($array_output_data, array(
					$checkbox,
					$branch,
					$tgl_bkk,
					$sub_register,
					$no_doc,
					$k_rek,
					$debit,
					$kredit,
					$no_perkiraan,
					$cc,
					$debit2,
					$kredit2,
					$keterangan,
					$project
				));
			}
			
			else
			{
				$debit = implode('<br>',arr_number_format(array_column($val['detail'],'debit')));
				$kredit = implode('<br>',arr_number_format(array_column($val['detail'],'credit')));
				
				array_push($array_output_data, array(
					$checkbox,
					$branch,
					$tgl_bkk,
					$sub_register,
					$no_doc,
					$k_rek,
					$debit,
					$kredit,
					$no_perkiraan,
					$cc,
					$keterangan,
					$project
				));
			}
        }
		
        $array_data = array(
            "draw" => $draw,
            "recordsTotal" => $total,
            "recordsFiltered" => $total,
            "data" => $array_output_data
        );
        
        echo json_encode($array_data);
    }
	
}